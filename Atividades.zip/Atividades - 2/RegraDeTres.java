/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Scanner;

public class RegraDeTres {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Digite o valor de A (ou '0' para sair): ");
            double A = scanner.nextDouble();
            if (A == 0) {
                System.out.println("Saindo...");
                break;
            }

            System.out.print("Digite o valor de B: ");
            double B = scanner.nextDouble();
            System.out.print("Digite o valor de C: ");
            double C = scanner.nextDouble();

            double X = (B * C) / A;
            System.out.println("O valor de X é: " + X);
        }
        scanner.close();
    }
}
