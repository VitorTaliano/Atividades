/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Random;
import java.util.Scanner;

public class JogoAdivinhacao {
    public static void main(String[] args) {
        Random random = new Random();
        int numeroAleatorio = random.nextInt(100) + 1; // Número aleatório entre 1 e 100
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Adivinhe o número entre 1 e 100: ");
            int palpite = scanner.nextInt();

            if (palpite == numeroAleatorio) {
                System.out.println("ACERTOU!");
                break;
            } else if (palpite < numeroAleatorio) {
                System.out.println("MAIOR");
            } else {
                System.out.println("MENOR");
            }
        }
        scanner.close();
    }
}
