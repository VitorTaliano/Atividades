/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Scanner;

public class Programa3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Informe o valor cheio da compra: ");
        double valorCheio = scanner.nextDouble();
        
        System.out.print("Informe o valor do desconto: ");
        double desconto = scanner.nextDouble();
        
        double novoValor = valorCheio - desconto;
        
        System.out.println("O valor cheio é: " + valorCheio);
        System.out.println("O valor do desconto é: " + desconto);
        System.out.println("O novo valor é: " + novoValor);
        
        scanner.close();
    }
}
