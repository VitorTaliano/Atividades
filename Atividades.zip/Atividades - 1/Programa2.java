/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Scanner;

public class Programa2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();
        
        String parOuImpar = (numero % 2 == 0) ? "par" : "ímpar";
        String positivoOuNegativo = (numero >= 0) ? "positivo" : "negativo";
        
        boolean primo = isPrimo(numero);
        
        System.out.println("O número é: " + parOuImpar);
        System.out.println("O número é: " + positivoOuNegativo);
        System.out.println("O número é primo: " + (primo ? "sim" : "não"));
        System.out.println("A raiz quadrada do número: " + Math.sqrt(numero));
        System.out.println("O número elevado a 3 é: " + (Math.pow(numero, 3)));
        
        scanner.close();
    }

    public static boolean isPrimo(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
}
