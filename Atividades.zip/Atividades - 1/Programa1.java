/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Scanner;

public class Programa1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite uma palavra: ");
        String palavra = scanner.nextLine();
        
        System.out.println("A palavra digitada foi: " + palavra);
        System.out.println("A palavra tem " + palavra.length() + " dígitos");
        System.out.println("A primeira letra é: " + palavra.charAt(0));
        
        char letraCentral = (palavra.length() % 2 != 0) ? 
                            palavra.charAt(palavra.length() / 2) : ' ';
        System.out.println("A letra central da palavra é: " + letraCentral);
        System.out.println("A última letra é: " + palavra.charAt(palavra.length() - 1));
        System.out.println("A palavra escrita ao contrário é: " + new StringBuilder(palavra).reverse().toString());
        System.out.println("A palavra toda em maiúsculo: " + palavra.toUpperCase());
        System.out.println("A palavra toda em minúsculo: " + palavra.toLowerCase());
        
        scanner.close();
    }
}
