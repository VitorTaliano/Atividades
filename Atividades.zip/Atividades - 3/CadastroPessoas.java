/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Scanner;

public class CadastroPessoas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[][] cadastro = new String[100][3]; // ID, Nome, Data de Nascimento
        int contador = 0;

        while (true) {
            System.out.println("Escolha uma opção:");
            System.out.println("1. Inserir pessoa");
            System.out.println("2. Alterar dados da pessoa");
            System.out.println("3. Consultar dados da pessoa");
            System.out.println("4. Excluir dados da pessoa");
            System.out.println("5. Sair");

            int escolha = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            if (escolha == 5) {
                System.out.println("Saindo...");
                break;
            }

            switch (escolha) {
                case 1:
                    if (contador < 100) {
                        System.out.print("ID: ");
                        cadastro[contador][0] = scanner.nextLine();
                        System.out.print("Nome: ");
                        cadastro[contador][1] = scanner.nextLine();
                        System.out.print("Data de Nascimento: ");
                        cadastro[contador][2] = scanner.nextLine();
                        contador++;
                        System.out.println("Pessoa cadastrada com sucesso!");
                    } else {
                        System.out.println("Cadastro cheio!");
                    }
                    break;

                case 2:
                    System.out.print("Digite o ID da pessoa a ser alterada: ");
                    String idAlterar = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idAlterar)) {
                            System.out.print("Novo Nome: ");
                            cadastro[i][1] = scanner.nextLine();
                            System.out.print("Nova Data de Nascimento: ");
                            cadastro[i][2] = scanner.nextLine();
                            System.out.println("Dados alterados com sucesso!");
                            break;
                        }
                    }
                    break;

                case 3:
                    System.out.print("Digite o ID da pessoa a ser consultada: ");
                    String idConsultar = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idConsultar)) {
                            System.out.println("ID: " + cadastro[i][0]);
                            System.out.println("Nome: " + cadastro[i][1]);
                            System.out.println("Data de Nascimento: " + cadastro[i][2]);
                            break;
                        }
                    }
                    break;

                case 4:
                    System.out.print("Digite o ID da pessoa a ser excluída: ");
                    String idExcluir = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idExcluir)) {
                            // Move todos os dados a frente
                            for (int j = i; j < contador - 1; j++) {
                                cadastro[j] = cadastro[j + 1];
                            }
                            cadastro[contador - 1] = null; // Limpa o último elemento
                            contador--;
                            System.out.println("Dados excluídos com sucesso!");
                            break;
                        }
                    }
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        }
        scanner.close();
    }
}
