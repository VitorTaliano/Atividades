/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Random;
import java.util.Scanner;

public class JogoDaVelha {
    private static char[][] tabuleiro = {
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '}
    };
    private static char jogador = 'X';
    private static char computador = 'O';
    private static Scanner scanner = new Scanner(System.in);
    private static Random random = new Random();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Escolha a dificuldade:");
            System.out.println("1. Normal");
            System.out.println("2. Difícil");
            System.out.println("3. Sair");
            int escolha = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            if (escolha == 3) {
                System.out.println("Saindo...");
                break;
            }

            while (true) {
                resetTabuleiro();
                boolean jogoAtivo = true;

                while (jogoAtivo) {
                    mostrarTabuleiro();
                    System.out.print("Jogador, escolha sua posição (1-9): ");
                    int posicao = scanner.nextInt() - 1;

                    if (posicao < 0 || posicao > 8 || tabuleiro[posicao / 3][posicao % 3] != ' ') {
                        System.out.println("Posição inválida, tente novamente.");
                        continue;
                    }

                    tabuleiro[posicao / 3][posicao % 3] = jogador;

                    if (verificarVencedor(jogador)) {
                        mostrarTabuleiro();
                        System.out.println("Você ganhou!");
                        jogoAtivo = false;
                        break;
                    }

                    if (tabuleiroCompleto()) {
                        mostrarTabuleiro();
                        System.out.println("Empate!");
                        jogoAtivo = false;
                        break;
                    }

                    if (escolha == 1) {
                        jogadaComputadorNormal();
                    } else {
                        jogadaComputadorDificil();
                    }

                    if (verificarVencedor(computador)) {
                        mostrarTabuleiro();
                        System.out.println("O computador ganhou!");
                        jogoAtivo = false;
                    }

                    if (tabuleiroCompleto()) {
                        mostrarTabuleiro();
                        System.out.println("Empate!");
                        jogoAtivo = false;
                    }
                }

                // Perguntar se o jogador deseja jogar novamente
                System.out.print("Deseja jogar novamente? (s/n): ");
                char resposta = scanner.next().charAt(0);
                if (resposta != 's' && resposta != 'S') {
                    break;
                }
            }
        }
        scanner.close();
    }

    private static void mostrarTabuleiro() {
        System.out.println(" " + tabuleiro[0][0] + " | " + tabuleiro[0][1] + " | " + tabuleiro[0][2]);
        System.out.println("---|---|---");
        System.out.println(" " + tabuleiro[1][0] + " | " + tabuleiro[1][1] + " | " + tabuleiro[1][2]);
        System.out.println("---|---|---");
        System.out.println(" " + tabuleiro[2][0] + " | " + tabuleiro[2][1] + " | " + tabuleiro[2][2]);
    }

    private static void resetTabuleiro() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tabuleiro[i][j] = ' ';
            }
        }
    }

    private static boolean verificarVencedor(char simbolo) {
        for (int i = 0; i < 3; i++) {
            if ((tabuleiro[i][0] == simbolo && tabuleiro[i][1] == simbolo && tabuleiro[i][2] == simbolo) ||
                (tabuleiro[0][i] == simbolo && tabuleiro[1][i] == simbolo && tabuleiro[2][i] == simbolo)) {
                return true;
            }
        }
        return (tabuleiro[0][0] == simbolo && tabuleiro[1][1] == simbolo && tabuleiro[2][2] == simbolo) ||
               (tabuleiro[0][2] == simbolo && tabuleiro[1][1] == simbolo && tabuleiro[2][0] == simbolo);
    }

    private static boolean tabuleiroCompleto() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    private static void jogadaComputadorNormal() {
        int posicao;
        do {
            posicao = random.nextInt(9);
        } while (tabuleiro[posicao / 3][posicao % 3] != ' ');

        tabuleiro[posicao / 3][posicao % 3] = computador;
    }

    private static void jogadaComputadorDificil() {
        // Tentativa de ganhar
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] == ' ') {
                    tabuleiro[i][j] = computador;
                    if (verificarVencedor(computador)) {
                        return; // Ganhar
                    }
                    tabuleiro[i][j] = ' '; // Desfaz a jogada
                }
            }
        }

        // Bloquear jogada do jogador
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] == ' ') {
                    tabuleiro[i][j] = jogador;
                    if (verificarVencedor(jogador)) {
                        tabuleiro[i][j] = computador; // Bloquear
                        return;
                    }
                    tabuleiro[i][j] = ' '; // Desfaz a jogada
                }
            }
        }

        // Jogada aleatória se não for possível ganhar ou bloquear
        jogadaComputadorNormal();
    }
}
