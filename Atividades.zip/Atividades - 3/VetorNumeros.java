/*
Vitor Taliano
Desenvolvimento de aplicações
TCTG241CNTDEV
*/

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class VetorNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Integer[] numeros = new Integer[10];

        // Inserir números no vetor
        System.out.println("Insira 10 números:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        // A. Lista com os números obtidos
        System.out.println("Lista de números obtidos: " + Arrays.toString(numeros));

        // B. Lista com os números ordenados em ordem crescente
        Arrays.sort(numeros);
        System.out.println("Lista ordenada em ordem crescente: " + Arrays.toString(numeros));

        // C. Lista com os números ordenados em ordem decrescente
        Arrays.sort(numeros, Collections.reverseOrder());
        System.out.println("Lista ordenada em ordem decrescente: " + Arrays.toString(numeros));

        scanner.close();
    }
}
